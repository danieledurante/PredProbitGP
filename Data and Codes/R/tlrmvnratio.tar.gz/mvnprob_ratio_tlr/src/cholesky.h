#ifndef CHOLESKY_H
#define CHOLESKY_H
#include <RcppEigen.h>
int cholesky(Eigen::MatrixXd& A);
#endif
