#ifndef INVERSE_H
#define INVERSE_H 
#include <RcppEigen.h>
int inverse(Eigen::MatrixXd& A);
#endif
