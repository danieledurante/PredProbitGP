## Test environments
* local macOS 10.13.4, R 3.6.1
* local Ubuntu 16.04.6 LTS, R 3.6.2
* win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs. 

## Downstream dependencies
There are currently no downstream dependencies for this package based on the results of `tools::package_dependencies`.

